if(!window.Scribd) Scribd = {};

Scribd.ServerOptions = {"reading_history_scroll_timeout":500,"sidebar_promo_enabled":false,"payments_store_disabled":false,"document_recommendations_test_enabled":true,"recommender_test_enabled":true,"ad_refresh_idle_time_before_inactive":60,"facebook_autologin_enabled":true,"recommender_test_choices":["control","test"],"disable_trending":false,"ad_refresh_interval":120,"ad_refresh_engagement_tracking_delay":1200};
